"use strict";
(() => {
  // src/background.ts
  var ENTRA_TENANT_ID = "9d72ea67-fd3f-46fd-9c1e-0b8783b74da6";
  var ENTRA_CLIENT_ID = "7c53e643-fae4-47b7-80a6-215b0412bc58";
  var ENTRA_REDIRECT_URI = "https://eaeapeepjigmbpbpohaobdkbnknihjpp.chromiumapp.org/";
  var ENTRA_SCOPES = "openid profile email";
  var ONBOARDING_FLOW_SEQUENCE = [
    "upload-first-batch",
    "review-denial",
    "upload-era",
    "view-scrub-rules",
    "view-memory-patterns"
  ];
  chrome.runtime.onInstalled.addListener(async (details) => {
    if (details.reason === "install") {
      await chrome.storage.local.set({
        isFirstInstall: true,
        preferences: { tutorMode: true, voiceEnabled: false },
        onboardingProgress: { currentFlowIndex: 0, completedFlows: [] }
      });
      const tabs = await getAltairTabs();
      for (const tab of tabs) {
        if (tab.id) sendToTab(tab.id, { type: "SHOW_WELCOME" });
      }
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const tabId = sender.tab?.id;
    handleMessage(message, tabId).then(sendResponse).catch((error) => {
      console.error("[background] unhandled error:", error);
      sendResponse(null);
    });
    return true;
  });
  async function handleMessage(message, senderTabId) {
    switch (message.type) {
      case "TRANSCRIPT_READY":
        await processTranscript(message.text, senderTabId);
        break;
      case "STEP_COMPLETE":
        await advanceFlow(senderTabId);
        break;
      case "CLOSE_FLOW":
        await chrome.storage.local.remove("activeFlow");
        break;
      case "URL_CHANGED":
        await handleUrlChanged(message.url, senderTabId);
        break;
      case "START_FLOW":
        await startFlow(message.slug, senderTabId);
        break;
      case "START_ONBOARDING":
        await startOnboarding(senderTabId);
        break;
      case "GET_STATE":
        return loadState();
      case "SET_TUTOR_MODE": {
        const state = await loadState();
        await chrome.storage.local.set({
          preferences: { ...state.preferences, tutorMode: message.enabled }
        });
        break;
      }
      case "SET_VOICE_ENABLED": {
        const state = await loadState();
        await chrome.storage.local.set({
          preferences: { ...state.preferences, voiceEnabled: message.enabled }
        });
        break;
      }
      case "GET_TRANSCRIBE_TOKEN":
        return getTranscribeToken();
      case "SIGN_IN":
        return signInWithMicrosoft(true);
      case "SIGN_OUT":
        await chrome.storage.local.remove(["authToken", "authTokenExpiry", "authUserEmail"]);
        return null;
    }
    return null;
  }
  async function getValidIdToken() {
    const stored = await chrome.storage.local.get(["authToken", "authTokenExpiry"]);
    if (stored.authToken && stored.authTokenExpiry && stored.authTokenExpiry > Date.now() + 6e4) {
      return stored.authToken;
    }
    try {
      const token = await launchOAuthPKCE(false);
      if (token) return token;
    } catch {
    }
    try {
      return await launchOAuthPKCE(true);
    } catch {
      return null;
    }
  }
  async function signInWithMicrosoft(interactive) {
    const token = await launchOAuthPKCE(interactive);
    if (!token) return null;
    try {
      const payloadJson = atob(token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"));
      const payload = JSON.parse(payloadJson);
      const email = payload.upn ?? payload.preferred_username ?? "";
      await chrome.storage.local.set({ authUserEmail: email });
      return { email };
    } catch {
      return null;
    }
  }
  async function launchOAuthPKCE(interactive) {
    const codeVerifier = generateCodeVerifier();
    const codeChallenge = await computeCodeChallenge(codeVerifier);
    const state = generateRandomHex(16);
    const authUrl = new URL(
      `https://login.microsoftonline.com/${ENTRA_TENANT_ID}/oauth2/v2.0/authorize`
    );
    authUrl.searchParams.set("client_id", ENTRA_CLIENT_ID);
    authUrl.searchParams.set("response_type", "code");
    authUrl.searchParams.set("redirect_uri", ENTRA_REDIRECT_URI);
    authUrl.searchParams.set("scope", ENTRA_SCOPES);
    authUrl.searchParams.set("code_challenge", codeChallenge);
    authUrl.searchParams.set("code_challenge_method", "S256");
    authUrl.searchParams.set("state", state);
    if (!interactive) authUrl.searchParams.set("prompt", "none");
    const redirectUrl = await chrome.identity.launchWebAuthFlow({
      url: authUrl.toString(),
      interactive
    });
    if (!redirectUrl) return null;
    const code = new URL(redirectUrl).searchParams.get("code");
    if (!code) return null;
    const tokenResponse = await fetch(
      `https://login.microsoftonline.com/${ENTRA_TENANT_ID}/oauth2/v2.0/token`,
      {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: ENTRA_CLIENT_ID,
          grant_type: "authorization_code",
          code,
          redirect_uri: ENTRA_REDIRECT_URI,
          code_verifier: codeVerifier
        }).toString()
      }
    );
    if (!tokenResponse.ok) return null;
    const tokens = await tokenResponse.json();
    const { id_token: idToken, expires_in: expiresIn } = tokens;
    await chrome.storage.local.set({
      authToken: idToken,
      authTokenExpiry: Date.now() + (expiresIn ?? 3600) * 1e3
    });
    return idToken;
  }
  function generateCodeVerifier() {
    const bytes = new Uint8Array(32);
    crypto.getRandomValues(bytes);
    return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
  }
  async function computeCodeChallenge(verifier) {
    const data = new TextEncoder().encode(verifier);
    const hash = await crypto.subtle.digest("SHA-256", data);
    return btoa(String.fromCharCode(...new Uint8Array(hash))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
  }
  function generateRandomHex(bytes) {
    const arr = new Uint8Array(bytes);
    crypto.getRandomValues(arr);
    return Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("");
  }
  async function fetchWorker(path, options = {}) {
    const idToken = await getValidIdToken();
    if (!idToken) return null;
    const response = await fetch(`${"https://clicky-proxy.young-shadow-1ff3.workers.dev"}${path}`, {
      ...options,
      headers: {
        ...options.headers ?? {},
        Authorization: `Bearer ${idToken}`
      }
    });
    if (response.status !== 401) return response;
    await chrome.storage.local.remove(["authToken", "authTokenExpiry"]);
    const freshToken = await launchOAuthPKCE(false).catch(() => null) ?? await launchOAuthPKCE(true).catch(() => null);
    if (!freshToken) return null;
    return fetch(`${"https://clicky-proxy.young-shadow-1ff3.workers.dev"}${path}`, {
      ...options,
      headers: {
        ...options.headers ?? {},
        Authorization: `Bearer ${freshToken}`
      }
    });
  }
  async function getTranscribeToken() {
    const response = await fetchWorker("/transcribe-token", { method: "POST" });
    if (!response?.ok) return null;
    return response.json();
  }
  async function processTranscript(transcript, tabId) {
    const state = await loadState();
    const { activeFlow, preferences } = state;
    const messages = [
      ...activeFlow?.conversationHistory ?? [],
      { role: "user", content: transcript }
    ];
    const url = tabId ? await getTabUrl(tabId) : "";
    const response = await fetchWorker("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages,
        url,
        domExcerpt: "",
        flowSlug: activeFlow?.slug,
        stepId: activeFlow?.stepId ?? void 0
      })
    });
    if (!response) {
      if (tabId) {
        sendToTab(tabId, {
          type: "SHOW_MESSAGE",
          speechText: "Please sign in to use Clicky. Click the Clicky icon in your toolbar.",
          audioDataUrl: null
        });
      }
      return;
    }
    if (!response.ok) {
      console.error("[background] /chat error:", response.status, await response.text());
      return;
    }
    const resolvedFlowSlug = response.headers.get("x-clicky-flow-slug") || activeFlow?.slug || null;
    const fullText = await accumulateSSEStream(response);
    const anchorMatch = fullText.match(/\[ANCHOR:([^\]]+)\]/);
    const clickMatch = fullText.match(/\[CLICK:([^\]]+)\]/);
    const anchor = anchorMatch?.[1] ?? clickMatch?.[1] ?? null;
    const autoClick = !!clickMatch;
    const flowDone = fullText.includes("FLOW_DONE");
    const stepComplete = fullText.includes("STEP_COMPLETE") && !flowDone;
    const signalIdx = flowDone ? fullText.indexOf("FLOW_DONE") : stepComplete ? fullText.indexOf("STEP_COMPLETE") : -1;
    const textToSpeak = signalIdx >= 0 ? fullText.slice(0, signalIdx) : fullText;
    const speechText = textToSpeak.replace(/\[ANCHOR:[^\]]+\]/g, "").replace(/\[CLICK:[^\]]+\]/g, "").replace(/\s{2,}/g, " ").trim();
    const updatedHistory = [
      ...messages,
      { role: "assistant", content: speechText || fullText }
    ];
    if (resolvedFlowSlug && !activeFlow) {
      await chrome.storage.local.set({
        activeFlow: {
          slug: resolvedFlowSlug,
          stepId: null,
          conversationHistory: updatedHistory,
          startedAt: Date.now()
        }
      });
    } else if (activeFlow && !flowDone) {
      await chrome.storage.local.set({
        activeFlow: { ...activeFlow, conversationHistory: updatedHistory }
      });
    }
    const audioDataUrl = preferences?.voiceEnabled !== false ? await fetchTTSDataUrl(speechText) : null;
    if (tabId) {
      const msg = flowDone ? { type: "FLOW_DONE", anchor, autoClick, speechText, audioDataUrl } : { type: "SHOW_STEP", anchor, autoClick, speechText, audioDataUrl, flowSlug: resolvedFlowSlug, hasNext: stepComplete };
      sendToTab(tabId, msg);
    }
    if (flowDone) {
      await chrome.storage.local.remove("activeFlow");
      await advanceOnboardingSequence(resolvedFlowSlug, tabId);
    }
  }
  async function advanceFlow(tabId) {
    const state = await loadState();
    if (state.activeFlow && Date.now() - state.activeFlow.startedAt > 30 * 60 * 1e3) {
      await chrome.storage.local.remove("activeFlow");
      if (tabId) {
        sendToTab(tabId, {
          type: "SHOW_MESSAGE",
          speechText: "That flow timed out. Start a new one whenever you're ready.",
          audioDataUrl: null
        });
      }
      return;
    }
    await processTranscript("[The user completed the step. Move to the next step.]", tabId);
  }
  async function startFlow(slug, tabId) {
    await chrome.storage.local.set({
      activeFlow: {
        slug,
        stepId: null,
        conversationHistory: [],
        startedAt: Date.now()
      }
    });
    await processTranscript(`Begin guiding me through the flow: ${slug}`, tabId);
  }
  async function startOnboarding(tabId) {
    const { onboardingProgress } = await loadState();
    const index = onboardingProgress?.currentFlowIndex ?? 0;
    const slug = ONBOARDING_FLOW_SEQUENCE[index];
    if (slug) await startFlow(slug, tabId);
  }
  async function advanceOnboardingSequence(completedSlug, tabId) {
    if (!completedSlug) return;
    const state = await loadState();
    const progress = state.onboardingProgress;
    if (!progress) return;
    const currentExpected = ONBOARDING_FLOW_SEQUENCE[progress.currentFlowIndex];
    if (currentExpected !== completedSlug) return;
    const nextIndex = progress.currentFlowIndex + 1;
    const completedFlows = [...progress.completedFlows, completedSlug];
    await chrome.storage.local.set({
      onboardingProgress: { currentFlowIndex: nextIndex, completedFlows }
    });
    const nextSlug = ONBOARDING_FLOW_SEQUENCE[nextIndex];
    if (nextSlug && tabId) {
      setTimeout(() => startFlow(nextSlug, tabId), 2e3);
    }
  }
  async function handleUrlChanged(url, tabId) {
    const { preferences, activeFlow } = await loadState();
    if (activeFlow) return;
    if (!preferences?.tutorMode) return;
    const response = await fetchWorker("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [{
          role: "user",
          content: `The user just navigated to ${url}. Offer a brief one-sentence proactive tip or ask if they need guidance \u2014 only if genuinely useful. If no tip is needed, respond with exactly: NO_TIP`
        }],
        url,
        domExcerpt: ""
      })
    });
    if (!response?.ok) return;
    const text = await accumulateSSEStream(response);
    if (!text.trim() || text.includes("NO_TIP")) return;
    const audioDataUrl = preferences.voiceEnabled !== false ? await fetchTTSDataUrl(text) : null;
    if (tabId) {
      sendToTab(tabId, { type: "SHOW_MESSAGE", speechText: text, audioDataUrl });
    }
  }
  async function fetchTTSDataUrl(text) {
    if (!text.trim()) return null;
    try {
      const response = await fetchWorker("/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, model_id: "eleven_flash_v2_5" })
      });
      if (!response?.ok) return null;
      const buffer = await response.arrayBuffer();
      return arrayBufferToDataUrl(buffer, "audio/mpeg");
    } catch (error) {
      console.error("[background] TTS error:", error);
      return null;
    }
  }
  function arrayBufferToDataUrl(buffer, mimeType) {
    const bytes = new Uint8Array(buffer);
    let binary = "";
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return `data:${mimeType};base64,${btoa(binary)}`;
  }
  async function accumulateSSEStream(response) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      for (const line of chunk.split("\n")) {
        if (!line.startsWith("data: ")) continue;
        const data = line.slice(6).trim();
        if (data === "[DONE]") break;
        try {
          const parsed = JSON.parse(data);
          fullText += parsed.choices[0]?.delta?.content ?? "";
        } catch {
        }
      }
    }
    return fullText;
  }
  async function loadState() {
    return chrome.storage.local.get(null);
  }
  async function getTabUrl(tabId) {
    try {
      const tab = await chrome.tabs.get(tabId);
      return tab.url ?? "";
    } catch {
      return "";
    }
  }
  async function getAltairTabs() {
    return chrome.tabs.query({
      url: ["https://altair-health.com/*", "https://beta.altair-health.com/*"]
    });
  }
  function sendToTab(tabId, message) {
    chrome.tabs.sendMessage(tabId, message).catch(() => {
    });
  }
})();
